var reda = eval('var searchResultsObj = ' + { "results": [], "searchTerm": "\\" - alert(1) }//" });
console.log(reda)